#include <iostream>
#include <string>

#include "Filho.h"

using namespace std;

string Filho::toString() {
    return "Filho: " + this->nome;
}